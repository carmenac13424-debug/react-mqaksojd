# MedScribe RD — v41

Sistema integrado de documentación clínica para internistas en República Dominicana.

## Estructura

```
src/
├── App.jsx                    ← Orquestador principal, manejo de screens
├── data/
│   └── constants.js           ← Colores, datos clínicos, helpers
└── components/
    ├── Atoms.jsx              ← Bb, Toast, SoapBlock, useAutoSave, AIResumen
    ├── MedicalHistory.jsx     ← Modal historia con autocompletar
    ├── Medications.jsx        ← Meds con alertas clínicas
    ├── ResultsUpload.jsx      ← OCR asincrónico sin bloquear grabación
    ├── PrivateNoteDrawer.jsx  ← Notas privadas del médico
    ├── RecordingScreen.jsx    ← Grabación + panel ⊕ flotante
    └── SOAPReview.jsx         ← SOAP completo + firma colapsada
```

## Correr local

```bash
npm install
npm start
```

## StackBlitz

Importar este repositorio en https://stackblitz.com/

## Principios

- La IA propone. El médico decide.
- Nada entra automático sin aprobación médica.
- Sin integración hospitalaria — resultados llegan por WhatsApp/PDF/foto.
- Auto-save cada 12s. Recuperación offline.
- Exequatur + fecha/hora + ID único en cada firma.
