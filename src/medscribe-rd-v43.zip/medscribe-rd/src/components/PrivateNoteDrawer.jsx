import { useState, useEffect, useRef } from "react";
import { C, fmt } from "../data/constants";

// Ejemplos clínicos dominicanos reales
const NP_EJEMPLOS = [
  { t:"Sospecho poca adherencia — dice tomar todo pero PA no baja", cat:"adherencia" },
  { t:"Paciente minimiza consumo de alcohol", cat:"social" },
  { t:"Posible ansiedad somatizada — revisar en próxima consulta", cat:"dx" },
  { t:"Familia insiste en estudios innecesarios — manejar expectativas", cat:"familia" },
  { t:"Paciente trajo medicamentos vencidos — verificar farmacia", cat:"meds" },
  { t:"Considerar derivar a endocrinología por DM2 descontrolada", cat:"referir" },
  { t:"Preguntar sobre tabaquismo real en privado — negó frente a familia", cat:"social" },
  { t:"Posible no acceso a medicamentos por costo — explorar", cat:"social" },
  { t:"Revisar si completó esquema antibiótico anterior", cat:"meds" },
  { t:"Paciente lucía ansioso — podría ser síntoma cardíaco vs psiquiátrico", cat:"dx" },
];

const CAT_COLORS = {
  adherencia: {bg:"rgba(185,28,28,0.12)",border:"rgba(185,28,28,0.25)",text:"#FCA5A5"},
  social:     {bg:"rgba(217,119,6,0.12)", border:"rgba(217,119,6,0.25)", text:"#FCD34D"},
  dx:         {bg:"rgba(11,140,128,0.12)",border:"rgba(11,140,128,0.25)",text:C.teal},
  familia:    {bg:"rgba(124,58,237,0.12)",border:"rgba(124,58,237,0.25)",text:"#C4B5FD"},
  meds:       {bg:"rgba(29,78,216,0.12)", border:"rgba(29,78,216,0.25)", text:"#93C5FD"},
  referir:    {bg:"rgba(21,128,61,0.12)", border:"rgba(21,128,61,0.25)", text:"#6EE7B7"},
};

export default function PrivateNoteDrawer({open,onClose,notas,onChange,toast}){
  const[von,   setVon]  = useState(false);
  const[vs,    setVs]   = useState(0);
  const[txt,   setTxt]  = useState("");
  const[pend,  setPend] = useState(null);
  const[filter,setFilter]=useState(null);
  const tr = useRef(null);

  useEffect(()=>{
    if(von){ setVs(0); tr.current=setInterval(()=>setVs(x=>x+1),1000); }
    else clearInterval(tr.current);
    return()=>clearInterval(tr.current);
  },[von]);

  function add(t,f,cat){
    onChange([...notas,{id:"np"+Date.now(),t,f,cat:cat||"dx",ok:false}]);
    toast("📝 Nota privada añadida");
    setTxt("");
  }

  const filtered = filter ? NP_EJEMPLOS.filter(e=>e.cat===filter) : NP_EJEMPLOS;

  if(!open) return null;

  return(
    <div style={{position:"fixed",inset:0,background:"rgba(11,37,69,0.82)",
      display:"flex",alignItems:"flex-end",zIndex:200}} onClick={()=>{ if(!von) onClose(); }}>
      <div onClick={e=>e.stopPropagation()} style={{width:"100%",maxWidth:390,
        margin:"0 auto",background:"#0D2A4A",borderRadius:"20px 20px 0 0",
        padding:"16px 20px 36px",animation:"SU 0.25s ease",maxHeight:"80vh",
        display:"flex",flexDirection:"column"}}>

        <div style={{width:36,height:4,borderRadius:2,background:"rgba(255,255,255,0.2)",margin:"0 auto 14px",flexShrink:0}}/>

        <div style={{flexShrink:0,marginBottom:12}}>
          <p style={{fontWeight:800,fontSize:16,color:C.white,margin:"0 0 3px"}}>🩺 Nota privada del médico</p>
          <p style={{fontSize:10,color:"rgba(255,255,255,0.4)",margin:0,lineHeight:1.6}}>
            El paciente <strong style={{color:"rgba(255,255,255,0.65)"}}>nunca ve esto</strong>. 
            No entra en la nota final sin su aprobación explícita.
          </p>
        </div>

        <div style={{flex:1,overflowY:"auto"}}>
          {/* Notas ya añadidas */}
          {notas.length>0&&(
            <div style={{marginBottom:12}}>
              {notas.map(n=>{
                const cc=CAT_COLORS[n.cat]||CAT_COLORS.dx;
                return(
                  <div key={n.id} style={{display:"flex",alignItems:"flex-start",gap:8,
                    padding:"7px 10px",background:cc.bg,borderRadius:9,marginBottom:5,
                    border:"1px solid "+cc.border}}>
                    <span style={{fontSize:11,flexShrink:0,marginTop:1}}>📝</span>
                    <span style={{fontSize:11,color:cc.text,flex:1,lineHeight:1.4}}>{n.t}</span>
                    <button onClick={()=>onChange(notas.filter(x=>x.id!==n.id))}
                      style={{background:"transparent",border:"none",cursor:"pointer",
                        fontSize:12,color:"rgba(255,255,255,0.3)",flexShrink:0}}>×</button>
                  </div>
                );
              })}
            </div>
          )}

          {/* Confirmación dictado */}
          {pend&&(
            <div style={{background:"rgba(11,140,128,0.15)",borderRadius:12,
              padding:"12px 14px",marginBottom:12,border:"1px solid rgba(11,140,128,0.3)"}}>
              <p style={{fontSize:10,fontWeight:700,color:C.teal,margin:"0 0 4px"}}>🤖 IA transcribió:</p>
              <p style={{fontSize:13,fontWeight:600,color:C.white,margin:"0 0 10px",lineHeight:1.5}}>{pend}</p>
              <div style={{display:"flex",gap:7}}>
                <button onClick={()=>setPend(null)}
                  style={{flex:1,padding:"9px",borderRadius:9,border:"1px solid rgba(255,255,255,0.15)",
                    background:"transparent",cursor:"pointer",fontFamily:"Sora,sans-serif",fontSize:11,color:"rgba(255,255,255,0.5)"}}>✕</button>
                <button onClick={()=>{ add(pend,"audio","dx"); setPend(null); }}
                  style={{flex:2,padding:"9px",borderRadius:9,border:"none",
                    background:"linear-gradient(135deg,"+C.teal+",#0A7A6E)",cursor:"pointer",
                    fontFamily:"Sora,sans-serif",fontSize:12,fontWeight:800,color:C.white}}>✅ Añadir a borrador</button>
              </div>
            </div>
          )}

          {!pend&&(
            <>
              {/* Filtro por categoría */}
              <div style={{marginBottom:8}}>
                <p style={{fontSize:8,fontWeight:700,color:"rgba(255,255,255,0.3)",
                  textTransform:"uppercase",letterSpacing:0.7,margin:"0 0 5px"}}>Filtrar por:</p>
                <div style={{display:"flex",flexWrap:"wrap",gap:4}}>
                  {[{k:null,l:"Todas"},{k:"adherencia",l:"Adherencia"},{k:"social",l:"Social"},{k:"dx",l:"Diagnóstico"},{k:"meds",l:"Meds"},{k:"referir",l:"Referir"}].map(f=>(
                    <button key={f.k||"all"} onClick={()=>setFilter(f.k)}
                      style={{padding:"3px 9px",borderRadius:16,border:"1px solid rgba(255,255,255,0.15)",
                        background:filter===f.k?"rgba(11,140,128,0.3)":"transparent",cursor:"pointer",
                        fontFamily:"Sora,sans-serif",fontSize:9,fontWeight:600,
                        color:filter===f.k?C.teal:"rgba(255,255,255,0.5)"}}>
                      {f.l}
                    </button>
                  ))}
                </div>
              </div>

              {/* Ejemplos clínicos RD */}
              <p style={{fontSize:8,fontWeight:700,color:"rgba(255,255,255,0.3)",
                textTransform:"uppercase",letterSpacing:0.7,margin:"0 0 6px"}}>Toque para añadir:</p>
              <div style={{display:"flex",flexDirection:"column",gap:4,marginBottom:10}}>
                {filtered.slice(0,5).map((e,i)=>{
                  const cc=CAT_COLORS[e.cat]||CAT_COLORS.dx;
                  return(
                    <button key={i} onClick={()=>add(e.t,"sugerencia",e.cat)}
                      style={{textAlign:"left",padding:"8px 11px",borderRadius:9,
                        background:cc.bg,border:"1px solid "+cc.border,cursor:"pointer",
                        fontFamily:"Sora,sans-serif",fontSize:11,color:cc.text,lineHeight:1.4}}>
                      + {e.t}
                    </button>
                  );
                })}
              </div>

              {/* Dictado */}
              <div style={{background:von?"rgba(11,37,69,0.9)":"rgba(255,255,255,0.05)",
                borderRadius:12,padding:"11px 14px",marginBottom:8,
                border:"1px solid "+(von?"rgba(11,140,128,0.4)":"rgba(255,255,255,0.1)"),transition:"all 0.2s"}}>
                <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
                  <div style={{display:"flex",alignItems:"center",gap:10}}>
                    {von
                      ?<><div style={{width:9,height:9,borderRadius:"50%",background:"#EF4444",animation:"PL 1s infinite"}}/>
                          <span style={{fontFamily:"JetBrains Mono,monospace",fontSize:13,color:C.white,fontWeight:600}}>{fmt(vs)}</span></>
                      :<><span style={{fontSize:18}}>🎤</span>
                          <span style={{fontSize:13,fontWeight:600,color:"rgba(255,255,255,0.8)"}}>Dictar nota privada</span></>}
                  </div>
                  {von
                    ?<button onClick={()=>{ setVon(false); setPend("Sospecho poca adherencia — PA no mejora con medicamentos referidos"); }}
                        style={{padding:"7px 14px",borderRadius:20,border:"none",background:C.teal,
                          cursor:"pointer",fontFamily:"Sora,sans-serif",fontSize:11,fontWeight:700,color:C.white}}>✓ Listo</button>
                    :<button onClick={()=>setVon(true)}
                        style={{padding:"7px 14px",borderRadius:20,border:"none",
                          background:"linear-gradient(135deg,"+C.teal+",#0A9E92)",cursor:"pointer",
                          fontFamily:"Sora,sans-serif",fontSize:11,fontWeight:700,color:C.white}}>🎤 Dictar</button>}
                </div>
              </div>

              {/* Texto libre */}
              <div style={{display:"flex",gap:7}}>
                <input value={txt} onChange={e=>setTxt(e.target.value)}
                  onKeyDown={e=>{ if(e.key==="Enter"&&txt.trim()) add(txt.trim(),"manual","dx"); }}
                  placeholder="Escribir nota privada clínica…"
                  style={{flex:1,padding:"9px 11px",borderRadius:9,
                    border:"1px solid rgba(255,255,255,0.15)",fontSize:12,
                    fontFamily:"Sora,sans-serif",color:C.white,
                    background:"rgba(255,255,255,0.08)",outline:"none"}}/>
                <button onClick={()=>{ if(txt.trim()) add(txt.trim(),"manual","dx"); }}
                  style={{padding:"9px 13px",borderRadius:9,border:"none",background:C.teal,
                    cursor:"pointer",color:C.white,fontFamily:"Sora,sans-serif",fontWeight:700,fontSize:13}}>✓</button>
              </div>
            </>
          )}
        </div>

        <button onClick={()=>{ onClose(); setVon(false); }}
          style={{width:"100%",marginTop:12,padding:"11px",borderRadius:12,
            border:"1px solid rgba(255,255,255,0.12)",background:"transparent",
            color:"rgba(255,255,255,0.5)",fontFamily:"Sora,sans-serif",fontSize:12,cursor:"pointer",flexShrink:0}}>
          Cerrar
        </button>
      </div>
    </div>
  );
}
